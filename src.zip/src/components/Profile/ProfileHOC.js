import { connect } from "react-redux"
import Posts from "../Profile/Profile"

const mapStateToProps = state => {
    return {
        posts:state.posts.posts
    }
}

export default connect(mapStateToProps, {})(Posts)